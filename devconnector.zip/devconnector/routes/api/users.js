const express = require("express");
const router = express.Router();

//@endpoint /api/users/test
// @method : GET
// @Access : public
// @DEsc : test the user route

router.get("/test", (req, res) => {
  res.json({ msg: "user works" });
});

//@endpoint /api/users/register
// @method : post
// @Access : public
// @DEsc : to register the user

router.post("/register", (req, res) => {
  console.log(req.body);
  res.send(req.body);
});

module.exports = router;
