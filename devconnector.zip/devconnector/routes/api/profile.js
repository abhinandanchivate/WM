const express = require("express");
const router = express.Router();

//@endpoint /api/profile/test
// @method : GET
// @Access : public
// @DEsc : test the user route

router.get("/test", (req, res) => {
  res.json({ msg: "profile works" });
});

module.exports = router;
