import React, { Component } from "react";

export default class sample extends Component {
  render() {
    return <div>taking UI content & BL.</div>;
  }
}
